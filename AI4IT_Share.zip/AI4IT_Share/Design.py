import streamlit as st

st.set_page_config(layout="wide")

from streamlit_extras.app_logo import add_logo

add_logo("app_logo1.png",height=100)

from streamlit_extras.colored_header import colored_header

# st.header("📝 Design")
# st.write("""Apply AI for Design related use cases""")

# colored_header(
  #  label="📝 Design",
   # description="Apply AI for Design related use cases",
    # color_name="violet-70",
# )

st.subheader("📝 Design",divider="violet")
st.caption(":blue[Apply AI for Design related use cases]")

reduce_header_height_style = """
  <style>
    .block-container {padding-top:2.5rem;}
   </style>
"""
st.markdown(reduce_header_height_style, unsafe_allow_html=True)

tabd1, tabd2, tabd3, tabd4 = st.tabs(["Feature1","Feature2","Feature3","Feature4"])