import streamlit as st

st.set_page_config(layout="wide")

from streamlit_extras.app_logo import add_logo

add_logo("app_logo1.png",height=100)

# st.header("🛠️ Development")
#st.write("""Apply AI for Development related use cases""")

reduce_header_height_style = """
  <style>
    .block-container {padding-top:2rem;}
   </style>
"""
st.markdown(reduce_header_height_style, unsafe_allow_html=True)

st.subheader("🛠️ Development",divider="violet")
st.caption(":blue[Apply AI for Development related use cases]")

tabdev1, tabdev2, tabdev3, tabdev4 = st.tabs(["Code Generation","Feature2","Feature3","Feature4"])

st.write('<style>div.row-widget.stRadio > div{flex-direction:row;} </style>', unsafe_allow_html=True)

with tabdev1:
   tabdev1_LLM = st.radio("Model to use:",('LLama','Cohere','PALM'),key=31)

   tabdev1_reqment_text=st.text_area('Enter Functional Specs: ',key=11)

   submit_tab3 = st.button('Generate Code') 

   if submit_tab3:
       if tabdev1_LLM == "LLama":
          st.write("LLama not configured") 
       elif tabdev1_LLM == "PALM":
          st.write("PALM to be implemented")
       elif tabdev1_LLM == "Cohere":
          st.write("Cohere not implemented")