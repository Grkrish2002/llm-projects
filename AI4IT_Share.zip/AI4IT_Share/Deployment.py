import streamlit as st

st.set_page_config(layout="wide")

from streamlit_extras.app_logo import add_logo

from streamlit_extras.colored_header import colored_header

add_logo("app_logo1.png",height=100)

# st.header("🧬 Deployment")
# st.write("""Apply AI for Deployment related use cases""")

colored_header(
    label="🧬 Deployment",
    description="Apply AI for Deployment related use cases",
    color_name="violet-70",
)

reduce_header_height_style = """
  <style>
    .block-container {padding-top:2rem;}
   </style>
"""
st.markdown(reduce_header_height_style, unsafe_allow_html=True)

tabde1, tabde2, tabde3, tabde4 = st.tabs(["Feature1","Feature2","Feature3","Feature4"])